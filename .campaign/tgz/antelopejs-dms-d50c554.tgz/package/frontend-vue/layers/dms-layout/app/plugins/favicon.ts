import { computed } from "vue";
import type { DmsLogoSources } from "#dms-core/app/entries/shared/types/app-config";

const ICON_TYPES: Record<
  ReturnType<
    NonNullable<ReturnType<typeof FILE_EXTENSION.exec>>[number]["toLowerCase"]
  >,
  string
> = {
  svg: "image/svg+xml",
  png: "image/png",
  ico: "image/x-icon",
  webp: "image/webp",
};
const FILE_EXTENSION = /\.([a-z0-9]+)(?:[?#]|$)/i;
const LIGHT_SCHEME_MEDIA = "(prefers-color-scheme: light)";
const DARK_SCHEME_MEDIA = "(prefers-color-scheme: dark)";

type IconLink = {
  rel: "icon";
  href: string;
  type?: string;
  media?: string;
};

function iconLink(href: string, media?: string): IconLink {
  const extension = FILE_EXTENSION.exec(href)?.[1].toLowerCase() ?? "";
  const type = ICON_TYPES[extension];
  const link: IconLink = { rel: "icon", href };
  if (type) link.type = type;
  if (media) link.media = media;
  return link;
}

function faviconLinks(favicon: Partial<DmsLogoSources> = {}): IconLink[] {
  const { light, dark } = favicon;
  if (light && dark && light !== dark)
    return [
      iconLink(light, LIGHT_SCHEME_MEDIA),
      iconLink(dark, DARK_SCHEME_MEDIA),
    ];
  const icon = light || dark;
  return icon ? [iconLink(icon)] : [];
}

/**
 * The browser tab icon, `branding.logo.favicon`. Its light and dark files
 * follow the operating system's scheme: the browser draws the tab outside the
 * page, where the dashboard's color mode does not reach. The app config is
 * read inside the computed, so an edit applied in development without a
 * reload replaces the icon too.
 */
export default defineDmsPlugin(() => {
  useHead(
    computed(() => ({
      link: faviconLinks(useDmsAppConfig().branding.logo?.favicon),
    })),
  );
});
